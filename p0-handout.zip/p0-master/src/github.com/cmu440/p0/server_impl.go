// Implementation of a MultiEchoServer. Students should write their code in this file.

package p0

type multiEchoServer struct {
	// TODO: implement this!
}

// New creates and returns (but does not start) a new MultiEchoServer.
func New() MultiEchoServer {
	// TODO: implement this!
	return nil
}

func (mes *multiEchoServer) Start(port int) error {
	// TODO: implement this!
	return nil
}

func (mes *multiEchoServer) Close() {
	// TODO: implement this!
}

func (mes *multiEchoServer) Count() int {
	// TODO: implement this!
	return -1
}

// TODO: add additional methods/functions below!
